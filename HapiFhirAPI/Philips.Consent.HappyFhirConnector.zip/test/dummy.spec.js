const chai = require('chai')
const expect = chai.expect

describe('Dummy test', () => {
  it('evaluated as true', () => (expect(true).to.be.true))
})
